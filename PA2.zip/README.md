/*login: jaege211, x500_2
date: 03/09/18
name: Jason Jaeger, full_name2
id: 5129479, id_for_second_name*/

# CSCI4061_P2
Second Project

## note 1: assumes all executables are on the path, run PATH=$PATH:</path/to/executables> to temporarily get an executable on the path

## note 2: must run "make clean" after every compalation for make to work properly

## note 3: to compile type "make" and to run "Vote_Counter </path/to/start>"

# Purpose
The purpose of this program is to traverse a directory structur inorder to count votes and determine the winner of an election

# Contributions
We both helped with each others files but Jason wrote Aggregate_Votes and Vote_Counter and Zach wrote Leaf_Counter

# Extra Credit
Currently we are not doing extra credit
